from pygame import *

class FighterPlane(sprite.Sprite):
    """docstring for FighterPlane"""
    def __init__(self, img, loc):
        super(FighterPlane, self).__init__()
        #super().__init__()
        self.image = image.load(img)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = loc
        self.bullet_list = []
        self.alive = True
        self.timer = 0.0

    def rebirth(self):
        """docstring for update"""
        if time.get_ticks() - self.timer > 4000.0:
            self.timer = time.get_ticks()
            self.alive = True

    def events(self, event):
        """docstring for events"""
        if event.type == KEYDOWN and event.key == K_SPACE:
            # Fire a bullet if the user clicks the mouse button
            bullet = Bullet('up')
            # Set the bullet so it is where the player is
            bullet.rect.x = player.rect.x + (player.rect.width/2) - (bullet.bullet_width/2)
            bullet.rect.y = player.rect.y
            # Add the bullet to the lists
            self.bullet_list.append(bullet)
            #print("added bullet")

    def pressed_keys(self, pkeys):
        """docstring for pkeys"""
        if pkeys[K_UP]:
            self.rect.move_ip(0, -1)
        if pkeys[K_DOWN]:
            self.rect.move_ip(0, 1)
        if pkeys[K_LEFT]:
            self.rect.move_ip(-1, 0)
        if pkeys[K_RIGHT]:
            self.rect.move_ip(1, 0)

    def update(self, screen):
        """docstring for draw"""
        if self.alive == True:
            screen.blit(self.image, self.rect)

        if self.alive == False:
            self.rebirth()

        for bullet in self.bullet_list:
            bullet.draw(screen)

            if bullet.rect.y < -10:
                self.bullet_list.remove(bullet)
                #print("removed UP bullet: ", len(self.bullet_list))

class Bullet(sprite.Sprite):
    """ This class represents the bullet . """
    def __init__(self, direction):
        super(Bullet, self).__init__()
        #super().__init__()

        self.direction = direction
        self.bullet_width = 4
        #self.image = Surface([self.bullet_width, 10])
        #self.image.fill((0,0,0)) #BLACK
        self.image = image.load("bullet.png")
        self.rect = self.image.get_rect()
 
    def update(self, screen):
        """ Move the bullet. """
        if self.direction == 'up':
            self.rect.y -= 3
            #print("bullet up")
        if self.direction == 'down':
            self.rect.y += 3
            #print("bullet down")

        screen.blit(self.image, self.rect)

class EnemyPlane(FighterPlane):
    """docstring for EnemyPlane"""
    def __init__(self, img, loc):
        super(EnemyPlane, self).__init__(img, loc)
        self.right_direction = True
        self.bullet_list = []
        self.timer = 0.0

    def update(self, screen):
        """docstring for update"""
        if self.rect.x > SCREEN_WIDTH-self.rect.width:
            self.right_direction = False
        if self.rect.x < 0:
            self.right_direction = True

        if self.right_direction == True:
            new_pos = (1,0)
        else:
            new_pos = (-1,0)

        #print(self.rect.x)

        if new_pos: #if not ZeroDivisonError
            self.rect.x, self.rect.y = (self.rect.x + new_pos[0], self.rect.y + new_pos[1])

        if len(self.bullet_list)<5:
            if time.get_ticks() - self.timer > 1500.0:
                self.timer = time.get_ticks()
                bullet = Bullet('down')
                bullet.rect.x = self.rect.x + (self.rect.width/2)
                bullet.rect.y = self.rect.y + self.rect.height
                #print("bullet was maden.", bullet.direction)
                self.bullet_list.append(bullet)
                #print("made bullet",len(self.bullet_list))

        screen.blit(self.image, self.rect)

#    def draw(self, screen):
#        """docstring for draw"""
#        screen.blit(self.image, self.rect)
#
#        for bullet in self.bullet_list:
#            #screen.blit(bullet.image, bullet.rect)
#            bullet.draw(screen)
#            #print(bullet.rect.y)
#            if bullet.rect.y > SCREEN_HEIGHT:
#                self.bullet_list.remove(bullet)
#                #print("removed DOWN bullet: ", len(self.bullet_list))

class EnemiesGroup(sprite.Group):
    def __init__(self, columns, rows):
        sprite.Group.__init__(self)
        self.enemies = [[None] * columns for _ in range(rows)]
        self.columns = columns
        self.rows = rows



init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

screen = display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
#w, h = display.get_surface().get_size()

done = False

player = FighterPlane("ap1.png", (230,450))
x=player.rect.left
y=player.rect.top
enemy = EnemyPlane("ap2v.png", (180,30))
enemy2 = EnemyPlane("ap2v.png", (350,30))
clock = time.Clock()

enemy_list = sprite.Group()
enemy_list.add(enemy)
enemy_list.add(enemy2)

score = 0

allSprites = sprite.Group(enemy_list, player)
while not done:
    currentTime = time.get_ticks()

    for e in event.get():
        if e.type == QUIT:
            done = True
        if e.type == KEYDOWN and e.key == K_q:
            done = True
        player.events(e)

    pkeys = key.get_pressed()
    player.pressed_keys(pkeys)

    screen.fill((255, 255, 255))
    
    for bullet in player.bullet_list:
        enemy_hit_list = sprite.spritecollide(bullet, enemy_list, True, sprite.collide_mask)
        for enemy in enemy_hit_list:
            print("remove bullet")
            player.bullet_list.remove(bullet)
            #all_sprites_list.remove(bullet)
            score += 1
            print(score)

    for enemy in enemy_list:
        for bullet in enemy.bullet_list:
            if sprite.collide_mask(bullet, player):
                enemy.bullet_list.remove(bullet)
                #print("remove bullet")
                player.alive = False
                player.timer = time.get_ticks()

    allSprites.update(screen)

#    for enemy in enemy_list:
#        enemy.update()
#        enemy.draw(screen)
#    player.draw(screen)
#    display.flip()
    display.update()
    clock.tick(200)

#for enemy in enemy_list:
#    print("e b = ",len(enemy.bullet_list))
