enemy_rows=4
enemy_cols=5
enemyodds=100