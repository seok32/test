import pygame

class FighterPlane(pygame.sprite.Sprite):
    """docstring for FighterPlane"""
    def __init__(self, img, loc):
        super(FighterPlane, self).__init__()
        #super().__init__()
        self.image = pygame.image.load(img)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = loc
        self.bullet_list = []

    def update(self):
        """docstring for update"""
        pass

    def events(self, event):
        """docstring for events"""
        print("added bullet")
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            # Fire a bullet if the user clicks the mouse button
            bullet = Bullet('up')
            # Set the bullet so it is where the player is
            bullet.rect.x = player.rect.x + (player.rect.width/2) - (bullet.bullet_width/2)
            bullet.rect.y = player.rect.y
            # Add the bullet to the lists
            self.bullet_list.append(bullet)

    def pressed_keys(self, pkeys):
        """docstring for pkeys"""
        if pkeys[pygame.K_UP]:
            self.rect.move_ip(0, -1)
        if pkeys[pygame.K_DOWN]:
            self.rect.move_ip(0, 1)
        if pkeys[pygame.K_LEFT]:
            self.rect.move_ip(-1, 0)
        if pkeys[pygame.K_RIGHT]:
            self.rect.move_ip(1, 0)

    def draw(self, screen):
        """docstring for draw"""
        screen.blit(self.image, self.rect)
        for bullet in self.bullet_list:
            bullet.draw(screen)

            if bullet.rect.y < -10:
                self.bullet_list.remove(bullet)
                print("removed UP bullet: ", len(self.bullet_list))

class Bullet(pygame.sprite.Sprite):
    """ This class represents the bullet . """
    def __init__(self, direction):
        super(Bullet, self).__init__()
        #super().__init__()

        self.direction = direction
        self.bullet_width = 4
        #self.image = pygame.Surface([self.bullet_width, 10])
        #self.image.fill((0,0,0)) #BLACK
        self.image = pygame.image.load("bullet.png")
        self.rect = self.image.get_rect()
 
    def update(self):
        """ Move the bullet. """
        if self.direction == 'up':
            self.rect.y -= 3
            #print("b up")
        if self.direction == 'down':
            self.rect.y += 3
            #print("b down")

    def draw(self, screen):
        """docstring for draw"""
        self.update()
        screen.blit(self.image, self.rect)


class EnemyPlane(FighterPlane):
    """docstring for EnemyPlane"""
    def __init__(self, img, loc):
        super(EnemyPlane, self).__init__(img, loc)
        self.right_direction = True
        self.bullet_list = []
        self.timer = 0.0

    def update(self):
        """docstring for update"""
        if self.rect.x > SCREEN_WIDTH-self.rect.width:
            self.right_direction = False
        if self.rect.x < 0:
            self.right_direction = True

        if self.right_direction == True:
            new_pos = (1,0)
        else:
            new_pos = (-1,0)

        #print(self.rect.x)

        if new_pos: #if not ZeroDivisonError
            self.rect.x, self.rect.y = (self.rect.x + new_pos[0], self.rect.y + new_pos[1])

        if pygame.time.get_ticks() - self.timer > 1500.0:
            self.timer = pygame.time.get_ticks()
            bullet = Bullet('down')
            bullet.rect.x = self.rect.x + (self.rect.width/2)
            bullet.rect.y = self.rect.y + self.rect.height
            #print("bullet was maden.", bullet.direction)
            self.bullet_list.append(bullet)
            #print("made bullet",len(self.bullet_list))

#        self.update_bullets()
#
#    def update_bullets(self):
#        #print("update_bullets",len(self.bullet_list))
#        for bullet in self.bullet_list:
#            bullet.update()
#            #print("bullet fired!", bullet.direction)

    def draw(self, screen):
        """docstring for draw"""
        screen.blit(self.image, self.rect)
        #if self.bullet_list:
        for bullet in self.bullet_list:
            #screen.blit(bullet.image, bullet.rect)
            bullet.draw(screen)
            print(bullet.rect.y)
            if bullet.rect.y > SCREEN_HEIGHT:
                self.bullet_list.remove(bullet)
                print("removed DOWN bullet: ", len(self.bullet_list))
 
pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400

screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
#w, h = pygame.display.get_surface().get_size()

done = False

player = FighterPlane("ap1.png", (230,290))
x=player.rect.left
y=player.rect.top
enemy = EnemyPlane("ap2v.png", (180,30))
enemy2 = EnemyPlane("ap2v.png", (350,30))
clock = pygame.time.Clock()

score = 0

while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        player.events(event)

    pkeys = pygame.key.get_pressed()
    player.pressed_keys(pkeys)

    screen.fill((255, 255, 255))
    
#    for bullet in bullet_list:
#        enemy_hit_list = pygame.sprite.spritecollide(bullet, enemy_list, True, pygame.sprite.collide_mask)
#        for enemy in enemy_hit_list:
#            print("remove bullet")
#            bullet_list.remove(bullet)
#            all_sprites_list.remove(bullet)
#            score += 1
#            print(score)
# 
#        if bullet.rect.y < -10:
#            all_sprites_list.remove(bullet)
#            bullet_list.remove(bullet)
#            #print('bullets:', len(bullet_list))
 
    #if enemy_alive == True:
    #    screen.blit(enemy.image, enemy.rect)

    #if pygame.sprite.collide_rect(player,enemy):
#    for enemy in enemy_list:
#        for bullet in enemy.bullet_list:
#            all_sprites_list.add(bullet)
#
#        if pygame.sprite.collide_mask(player, enemy):
#            #print("collide")
#            #print((player.rect.left, player.rect.top))
#            #enemy_alive = False
#            all_sprites_list.remove(enemy)
#
#    all_sprites_list.draw(screen)
    enemy.update()
    player.draw(screen)
    enemy.draw(screen)
    pygame.display.flip()
    clock.tick(60)
