import pygame

class FighterPlane(pygame.sprite.Sprite):
    """docstring for FighterPlane"""
    def __init__(self, img, loc):
        super(FighterPlane, self).__init__()
        self.image = pygame.image.load(img)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = loc


pygame.init()

screen = pygame.display.set_mode((600,400))

done = False

player = FighterPlane("ap1.png", (30,30))
x=player.rect.left
y=player.rect.top
enemy = FighterPlane("ap2.png", (230,230))
clock = pygame.time.Clock()
enemy_alive = True

while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
    pkey = pygame.key.get_pressed()
    if pkey[pygame.K_UP]:
        y=y-1
    if pkey[pygame.K_DOWN]:
        y=y+1
    if pkey[pygame.K_LEFT]:
        x=x-1
    if pkey[pygame.K_RIGHT]:
        x=x+1

    screen.fill((255, 255, 255))
    #pygame.draw.rect(screen, (255,0,0), pygame.Rect((30,30,40,70)))
    #screen.blit(player_img, (x,y))
    player.rect.left = x
    player.rect.top = y
    screen.blit(player.image, player.rect)
    if enemy_alive == True:
        screen.blit(enemy.image, enemy.rect)
    #if pygame.sprite.collide_rect(player,enemy):
    if pygame.sprite.collide_mask(player, enemy):
        #print("collide")
        print((player.rect.left, player.rect.top))
        enemy_alive = False

    pygame.display.flip()
    clock.tick(150)

