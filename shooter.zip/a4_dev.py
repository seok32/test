import pygame

class FighterPlane(pygame.sprite.Sprite):
    """docstring for FighterPlane"""
    def __init__(self, img, loc):
        super(FighterPlane, self).__init__()
        #super().__init__()
        self.image = pygame.image.load(img)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = loc
        self.mask = pygame.mask.from_surface(self.image)

class Bullet(pygame.sprite.Sprite):
    """ This class represents the bullet . """
    def __init__(self):
        super(Bullet, self).__init__()
        #super().__init__()

        self.bullet_width = 2
        #self.image = pygame.Surface([self.bullet_width, 10])
        self.image = pygame.image.load("bullet.png")
        self.rect = self.image.get_rect()
        self.image.fill((0,0,0)) #BLACK
        self.mask = pygame.mask.from_surface(self.image)
 
    def update(self):
        """ Move the bullet. """
        self.rect.y -= 3

pygame.init()

screen = pygame.display.set_mode((600,400))

done = False

player = FighterPlane("ap1.png", (230,290))
x=player.rect.left
y=player.rect.top
enemy = FighterPlane("ap2v.png", (180,30))
enemy2 = FighterPlane("ap2v.png", (350,30))
clock = pygame.time.Clock()
#enemy_alive = True

all_sprites_list = pygame.sprite.Group()
bullet_list = pygame.sprite.Group()
enemy_list = pygame.sprite.Group()

all_sprites_list.add(player)
all_sprites_list.add(enemy)
all_sprites_list.add(enemy2)
enemy_list.add(enemy)
enemy_list.add(enemy2)
score = 0

print("enemy num:",len(enemy_list))
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        #elif event.type == pygame.MOUSEBUTTONDOWN:
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            # Fire a bullet if the user clicks the mouse button
            bullet = Bullet()
            # Set the bullet so it is where the player is
            bullet.rect.x = player.rect.x + (player.rect.width/2) - (bullet.bullet_width/2)
            bullet.rect.y = player.rect.y
            # Add the bullet to the lists
            all_sprites_list.add(bullet)
            bullet_list.add(bullet)

    pkey = pygame.key.get_pressed()
    if pkey[pygame.K_UP]:
        y=y-1
    if pkey[pygame.K_DOWN]:
        y=y+1
    if pkey[pygame.K_LEFT]:
        x=x-1
    if pkey[pygame.K_RIGHT]:
        x=x+1

    screen.fill((255, 255, 255))
    #pygame.draw.rect(screen, (255,0,0), pygame.Rect((30,30,40,70)))
    #screen.blit(player_img, (x,y))
    player.rect.left = x
    player.rect.top = y

    #screen.blit(player.image, player.rect)
    all_sprites_list.update()
    
    for bullet in bullet_list:
        #enemy_hit_list = pygame.sprite.spritecollide(bullet, enemy_list, True)
        for enemy in enemy_list:
            #if pygame.sprite.collide_rect(bullet, enemy):
            if pygame.sprite.collide_mask(bullet, enemy):
                print("remove bullet")
                bullet_list.remove(bullet)
                all_sprites_list.remove(bullet)
                enemy_list.remove(enemy)
                all_sprites_list.remove(enemy)
                score += 1
                print(score)
 
        if bullet.rect.y < -10:
            all_sprites_list.remove(bullet)
            bullet_list.remove(bullet)
            print('bullets:', len(bullet_list))
 
    #if enemy_alive == True:
    #    screen.blit(enemy.image, enemy.rect)

    #if pygame.sprite.collide_rect(player,enemy):
    for enemy in enemy_list:
        if pygame.sprite.collide_mask(player, enemy):
            #print("collide")
            #print((player.rect.left, player.rect.top))
            #enemy_alive = False
            all_sprites_list.remove(enemy)

    all_sprites_list.draw(screen)
    pygame.display.flip()
    clock.tick(200)

